# Minecraft-Like Game (Custom Textures, GUI + Basic Terrain)
# Gereksinim: pip install ursina
# Çalıştır: python Minecraft_like_playable_game.py

from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random, math, os

PLAYER_NAME = 'Mert'
BLOCK_SIZE = 1
HOTBAR_SLOTS = 8

app = Ursina()
window.title = 'Minecraft - Custom Textures Edition'
window.borderless = False
window.fps_counter.enabled = True
window.size = (1280, 720)
mouse.locked = True

# --- Sky ---
Sky(color=color.rgb(135, 206, 235))  # açık mavi gökyüzü

# --- Blok Türleri ---
block_types = ['grass', 'dirt', 'stone', 'wood', 'leaves']
hotbar_items = block_types * 2
selected_slot = 0
blocks = {}

# --- Voxel Sınıfı ---
class Voxel(Entity):
    def __init__(self, position=(0,0,0), block_type='grass'):
        texture_path = f'textures/{block_type}.png'
        super().__init__(
            parent=scene,
            position=position,
            model='cube',
            texture=texture_path if os.path.exists(texture_path) else None,
            scale=BLOCK_SIZE,
            collider='box'
        )
        self.block_type = block_type

# --- Arazi Üretimi ---
def generate_terrain(width=32, depth=32, height=1):
    for x in range(-width//2, width//2):
        for z in range(-depth//2, depth//2):
            for y in range(height):
                pos = (x, y, z)
                btype = 'grass' if y == height-1 else 'dirt'
                b = Voxel(position=pos, block_type=btype)
                blocks[pos] = b

# --- Ağaçlar ve Dekorasyon ---
def add_decorations():
    for i in range(40):
        x, z = random.randint(-10, 10), random.randint(-10, 10)
        pos = (x, 0, z)
        if pos in blocks:
            destroy(blocks[pos])
            b = Voxel(position=pos, block_type='stone')
            blocks[pos] = b
    # Basit ağaç
    trunk_x, trunk_z = 3, 4
    for y in range(1, 4):
        pos = (trunk_x, y, trunk_z)
        b = Voxel(position=pos, block_type='wood')
        blocks[pos] = b
    for dx in (-1, 0, 1):
        for dz in (-1, 0, 1):
            pos = (trunk_x + dx, 4, trunk_z + dz)
            b = Voxel(position=pos, block_type='leaves')
            blocks[pos] = b

# --- Arayüz (Hotbar) ---
hotbar_buttons = []
hotbar_parent = Entity(parent=camera.ui)
slot_size = 0.08
slot_spacing = 0.01
start_x = -(HOTBAR_SLOTS * slot_size + (HOTBAR_SLOTS - 1) * slot_spacing) / 2
for i in range(HOTBAR_SLOTS):
    x = start_x + i * (slot_size + slot_spacing)
    btn = Button(parent=camera.ui, scale=(slot_size, slot_size), x=x, y=-0.38)
    tex_path = f'textures/{hotbar_items[i]}.png'
    btn.texture = tex_path if os.path.exists(tex_path) else None
    hotbar_buttons.append(btn)
selected_frame = Entity(
    parent=camera.ui,
    model='quad',
    color=color.rgba(255, 255, 255, 120),
    scale=(slot_size + 0.005, slot_size + 0.005),
    y=-0.38
)

def update_selected_frame():
    x = start_x + selected_slot * (slot_size + slot_spacing)
    selected_frame.x = x
update_selected_frame()

# --- Oyuncu ---
player = FirstPersonController(y=2, speed=5)
player.gravity = 0.5
player.jump_height = 1.5
player.cursor = Entity(parent=camera.ui, model='quad', color=color.white, scale=0.002)

Text(text=PLAYER_NAME, parent=camera.ui, origin=(0, -.5), position=(-0.95, 0.42), scale=1.2)
Text(text='WASD Move | Mouse Look | LMB Break | RMB Place | 1-8 Slots',
     parent=camera.ui, position=(-0.6, -0.46), scale=0.6)

# --- Giriş (Input) ---
def input(key):
    global selected_slot
    if key.isdigit() and 1 <= int(key) <= HOTBAR_SLOTS:
        selected_slot = int(key) - 1
        update_selected_frame()
    if key == 'left mouse down':
        hit = raycast(camera.world_position, camera.forward, distance=6, ignore=(player,))
        if hit.entity and isinstance(hit.entity, Voxel):
            pos = tuple(map(int, hit.entity.position))
            destroy(hit.entity)
            blocks.pop(pos, None)
    if key == 'right mouse down':
        hit = raycast(camera.world_position, camera.forward, distance=6, ignore=(player,))
        if hit.entity and isinstance(hit.entity, Voxel):
            place_pos = hit.entity.position + hit.normal
            place_pos = (int(round(place_pos.x)), int(round(place_pos.y)), int(round(place_pos.z)))
            if place_pos not in blocks and place_pos[1] >= 0:
                btype = hotbar_items[selected_slot]
                b = Voxel(position=place_pos, block_type=btype)
                blocks[place_pos] = b

# --- Update (Her Karede) ---
def update():
    selected_frame.y = -0.38
    if held_keys['w'] or held_keys['a'] or held_keys['s'] or held_keys['d']:
        camera.y = 0.1 * math.sin(time.time() * 6)
    else:
        camera.y = 0

# --- Dünya Kurulumu ---
generate_terrain()
add_decorations()

# --- Başlat ---
Entity(parent=camera.ui, model='quad', color=color.black, scale=0.003)
app.run()
